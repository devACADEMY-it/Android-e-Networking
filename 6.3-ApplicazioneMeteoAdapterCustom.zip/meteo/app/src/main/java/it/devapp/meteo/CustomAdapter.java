/*
 * Android e Networking
 * Applicazione Meteo: Adapter custom
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.meteo;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class CustomAdapter extends BaseAdapter{

    private List<Citta> lista = null;

    CustomAdapter(){
        lista = new ArrayList<Citta>();
    }

    public void clear(){
        lista.clear();
    }

    public void add(Citta c){
        lista.add(c);
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return lista.size();
    }

    @Override
    public Object getItem(int position) {
        return lista.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null)
            convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row, null);
        TextView citta = (TextView) convertView.findViewById(R.id.nomecitta);
        TextView temperatura = (TextView) convertView.findViewById(R.id.temperatura);

        Citta c = (Citta) getItem(position);
        citta.setText(c.getNome());
        temperatura.setText(c.getTemperatura());
        return convertView;
    }
}
