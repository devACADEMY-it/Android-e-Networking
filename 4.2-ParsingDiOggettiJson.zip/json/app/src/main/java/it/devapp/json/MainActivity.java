/*
 * Android e Networking
 * Parsing di oggetti JSON
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.json;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    private TextView nome = null;
    private TextView cognome = null;
    private TextView eta = null;
    private TextView automunito = null;

    private void parsing(){

        String json = getString(R.string.esempiojson);

        try {
            JSONObject ob = new JSONObject(json);

            nome.setText("Nome: " + ob.getString("nome"));
            cognome.setText("Cognome: " + ob.getString("cognome"));
            eta.setText("Eta: " + ob.getString("eta"));
            if (ob.getBoolean("automunito"))
                automunito.setText("Automunito: Sì");
            else
                automunito.setText("Automunito: No");
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nome = (TextView) findViewById(R.id.nome);
        cognome = (TextView) findViewById(R.id.cognome);
        eta = (TextView) findViewById(R.id.eta);
        automunito = (TextView) findViewById(R.id.automunito);
    }

    public void aggiorna(View v){
        parsing();
    }
}
