/*
 * Android e Networking
 * NetworkImageView in Volley
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.applicazionemeteo;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Citta {

    private String nome;
    private double temperatura;
    private String id_icona;
    private static final String image_url_base="http://openweathermap.org/img/w/";

    /*
      {
        ...
        "weather":[
            {"id":500,"main":"Rain","description":"light rain","icon":"10d"}
        ],
        ...
        ...,
        "main":{"temp":284.96,"pressure":1011,"humidity":62,"temp_min":283.15,"temp_max":287.15},
        ...
        ...,
        "name":"London"
      }
   */
    public Citta(JSONObject j)
    {
        try {
            JSONObject main=j.getJSONObject("main");
            temperatura=convertiTemperatura(main.getDouble("temp"));
            nome=j.getString("name");
            JSONArray weather=j.getJSONArray("weather");
            if (weather.length()>0)
                id_icona=weather.getJSONObject(0).getString("icon");
        } catch (JSONException e) {

        }

    }

    public String getNome() {
        return nome;
    }

    public String getTemperatura() {
        return Long.toString(Math.round(temperatura))+" °C";
    }

    public String getImageUrl()
    {
        return image_url_base+id_icona+".png";
    }

    private double convertiTemperatura(double tempK) {
        return tempK - 273.15;
    }

    @Override
    public String toString() {
        return nome+" - "+getTemperatura();
    }
}
