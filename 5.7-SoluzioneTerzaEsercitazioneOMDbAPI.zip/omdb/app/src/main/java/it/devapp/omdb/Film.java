/*
 * Android e Networking
 * Soluzione Terza Esercitazione: "OMDb API"
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.omdb;

public class Film {
    String Title;
    String Plot;
    String Poster;
    String Year;
    String Actors;
}
