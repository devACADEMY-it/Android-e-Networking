/*
 * Android e Networking
 * Soluzione Terza Esercitazione: "OMDb API"
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.omdb;

import android.app.ProgressDialog;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.support.v4.graphics.BitmapCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.stream.MalformedJsonException;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.MalformedURLException;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    private TextView titolo;
    private TextView descrizione;
    private TextView attori;
    private TextView premi;
    private TextView dacercare;
    private RequestQueue queue;
    private ImageView poster;

    private Response.Listener<Bitmap> imageListener = new Response.Listener<Bitmap>() {
        @Override
        public void onResponse(Bitmap response) {
            poster.setImageBitmap(response);
        }
    };

    private Response.Listener<JSONObject> listener = new Response.Listener<JSONObject>() {
        @Override
        public void onResponse(JSONObject response) {
            try {
                String titoloConAnno = response.getString("Title") + " (" + response.getString("Year") + ")";
                titolo.setText(titoloConAnno);
                descrizione.setText(response.getString("Plot"));
                attori.setText(response.getString("Actors"));
                premi.setText(response.getString("Awards"));

                String posterUrl = response.getString("Poster");
                ImageRequest imageRequest = new ImageRequest(posterUrl, imageListener, 0, 0, null, null, errorListener);
                queue.add(imageRequest);

            } catch (JSONException e) {

            }
        }
    };

    private Response.ErrorListener errorListener = new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {
            //codice reazione all'errore
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        titolo = (TextView) findViewById(R.id.titolo);
        descrizione = (TextView) findViewById(R.id.descrizione);
        dacercare= (EditText) findViewById(R.id.dacercare);
        attori = (TextView) findViewById(R.id.attori);
        premi = (TextView) findViewById(R.id.premi);
        poster = (ImageView) findViewById(R.id.poster);

        queue = Volley.newRequestQueue(this);
    }

   private JsonObjectRequest preparaRichiesta(String url){
       return new JsonObjectRequest(url, null, listener, errorListener);
   }

    private String creaURL(String s){
        return "http://omdbapi.com/?t=" + s + "&y=&plot=short&r=json";
    }

    public void cerca(View v){

        String url = creaURL(dacercare.getText().toString());
        queue.add(preparaRichiesta(url));

    }
}
