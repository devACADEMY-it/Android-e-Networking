/*
 * Android e Networking
 * Applicazione Meteo: impostazione
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.meteo;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Citta {
    private String nome;
    private double temperatura;
    private String id_icona;
    private static final String image_url_base="https://openweathermap.org/img/w/";

    public Citta(JSONObject j){
        try {
            JSONObject main = j.getJSONObject("main");
            temperatura = convertiTemperatura(main.getDouble("temp"));
            nome = j.getString("name");
            JSONArray weather = j.getJSONArray("weather");
            if (weather.length() > 0)
                id_icona = weather.getJSONObject(0).getString("icon");
        } catch (JSONException e) {

        }

    }

    public String getNome() {
        return nome;
    }
    public String getTemperatura() {
        return Long.toString(Math.round(temperatura)) + " °C";
    }
    public String getImageUrl(){
        return image_url_base + id_icona + ".png";
    }

    private double convertiTemperatura(double tempk){
        return tempk - 273.15;
    }

    @Override
    public String toString() {
        return nome + " - " + getTemperatura();
    }
}