/*
 * Android e Networking
 * Attività asincrone con AsyncTask
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.asynctask;

import android.os.AsyncTask;
import android.support.annotation.IntegerRes;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private TextView txt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txt = (TextView) findViewById(R.id.txt);
    }

    public void avvia(View v){

        // gestione del click sul pulsante
        new BackgroundTask().execute();

    }

    private class BackgroundTask extends AsyncTask<Void, Integer, Void>{

        @Override
        protected Void doInBackground(Void... params) {

            for (int i=1; i<=100; i++){
                try {
                    Thread.sleep(50);
                    publishProgress(i);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            return null;
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
            txt.setText(Integer.toString(values[0])+"%");
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            Toast.makeText(MainActivity.this, "Operazioni concluse!", Toast.LENGTH_LONG).show();
        }
    }
}
