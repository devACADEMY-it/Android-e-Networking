/*
 * Android e Networking
 * Aspetti avanzati di Volley
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.meteo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    private ListView list;
    private String url_base ="http://api.openweathermap.org/data/2.5/weather";
    private CustomAdapter adapter;
    private RequestQueue queue;

    private Response.Listener<JSONObject> listener = new Response.Listener<JSONObject>() {
        @Override
        public void onResponse(JSONObject response) {
            Citta c = new Citta(response);
            adapter.add(c);

        }
    };

    private Response.ErrorListener errorListener = new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {

        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        queue = Volley.newRequestQueue(this);
        list = (ListView) findViewById(R.id.lista);
        adapter = new CustomAdapter();
        list.setAdapter(adapter);
        aggiornaValori();
    }

    private JsonObjectRequest preparaRichiesta(String citta){
        String url = url_base + "?q=" + citta + "&appid=" + getString(R.string.api_id);
        JsonObjectRequest r = new JsonObjectRequest(url, null, listener, errorListener);
        return r;
    }

    private void aggiornaValori(){
        adapter.clear();
        for (String citta:getResources().getStringArray(R.array.elenco_citta)){
            queue.add(preparaRichiesta(citta));
        }
    }



    public void aggiorna(View v){
        aggiornaValori();
    }
}