/*
 * Android e Networking
 * Soluzione Quarta Esercitazione: "App Meteo"
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.meteo;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Citta {
    private String nome;
    private double temperatura;
    private double temp_max;
    private String id_icona;
    private static final String image_url_base="http://openweathermap.org/img/w/";

    public Citta(JSONObject j){
        try {
            JSONObject main = j.getJSONObject("main");
            temperatura = convertiTemperatura(main.getDouble("temp"));
            temp_max= convertiTemperatura(main.getDouble("temp_max"));
            nome = j.getString("name");
            JSONArray weather = j.getJSONArray("weather");
            if (weather.length() > 0)
                id_icona = weather.getJSONObject(0).getString("icon");
        } catch (JSONException e) {

        }

    }

    public String getNome() {
        return nome;
    }
    public String getTemperatura() {

        String t = Long.toString(Math.round(temperatura)) + " °C (massima: " + Long.toString(Math.round(temp_max)) + " °C)";
        return t;
    }
    public String getImageUrl(){
        return image_url_base + id_icona + ".png";
    }

    private double convertiTemperatura(double tempk){
        return tempk - 273.15;
    }

    @Override
    public String toString() {
        return nome + " - " + getTemperatura();
    }
}