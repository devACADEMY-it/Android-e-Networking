/*
 * Android e Networking
 * Scaricare immagini con Picasso
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.omdb;

public class Film {
    String Title;
    String Plot;
    String Poster;
    String Year;
    String Actors;
}
