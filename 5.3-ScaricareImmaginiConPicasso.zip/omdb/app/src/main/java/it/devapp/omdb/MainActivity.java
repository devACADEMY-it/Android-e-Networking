/*
 * Android e Networking
 * Scaricare immagini con Picasso
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.omdb;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.stream.MalformedJsonException;
import com.squareup.picasso.Picasso;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.MalformedURLException;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    private TextView titolo;
    private TextView descrizione;
    private TextView attori;
    private TextView dacercare;
    private ImageView img;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        titolo = (TextView) findViewById(R.id.titolo);
        descrizione = (TextView) findViewById(R.id.descrizione);
        dacercare= (EditText) findViewById(R.id.dacercare);
        attori = (TextView) findViewById(R.id.attori);
        img = (ImageView) findViewById(R.id.img);
    }

    private class WebService extends AsyncTask<String, Void, Film>{

        private ProgressDialog progress = null;

        @Override
        protected void onPreExecute() {
            progress = ProgressDialog.show(MainActivity.this, "Download", "In corso...");
            dacercare.setText("");
            titolo.setText("");
            descrizione.setText("");
            attori.setText("");
            img.setImageDrawable(null);
        }
        @Override
        protected Film doInBackground(String... params) {
            Gson gson = new GsonBuilder().create();

            try {
                URL u = new URL(params[0]);
                Reader r = new InputStreamReader(u.openStream());
                return gson.fromJson(r, Film.class);

            } catch (MalformedURLException e){

            } catch (IOException e) {
            }
            return null;
        }

        @Override
        protected void onPostExecute(Film film) {
            progress.dismiss();
            if (film == null)
                Toast.makeText(MainActivity.this, "Film non trovato", Toast.LENGTH_SHORT).show();
            else{
                Picasso.with(MainActivity.this).load(film.Poster).into(img);
                titolo.setText(film.Title + " (" + film.Year + ")");
                descrizione.setText(film.Plot);
                attori.setText(film.Actors);
            }
        }
    }

    private String creaURL(String s){
        return "http://omdbapi.com/?t=" + s + "&y=&plot=short&r=json";
    }

    public void cerca(View v){

        String url = creaURL(dacercare.getText().toString());
        new WebService().execute(url);

    }
}
