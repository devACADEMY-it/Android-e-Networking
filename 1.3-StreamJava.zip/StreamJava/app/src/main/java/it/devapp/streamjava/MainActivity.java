/*
 * Android e Networking
 * Leggere dati in rete con gli Stream Java
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.streamjava;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    private TextView txt;
    private BackgroundTask task;
    private final static String REMOTE_ADDR="http://loripsum.net/api/2/short/headers/plaintext";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txt = (TextView) findViewById(R.id.txt);

    }

    public void avvia(View v){
        task = new BackgroundTask();
        task.execute();
    }

    private class BackgroundTask extends AsyncTask<Void, Void, String> {

        @Override
        protected String doInBackground(Void... params) {

            try {
                URL url = new URL(REMOTE_ADDR);

                InputStream is = url.openStream();

                BufferedReader buf = new BufferedReader(new InputStreamReader(is));

                StringBuffer sb = new StringBuffer();
                String s;

                while ((s=buf.readLine()) != null){
                    sb.append(s);
                }

                buf.close();
                return sb.toString();
                
            } catch (MalformedURLException e) {
                // Gestione eccezione
            } catch (IOException e) {
                // Gestione eccezione
            }

            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            if (s!=null){
                Toast.makeText(MainActivity.this, "Scaricamento completato!", Toast.LENGTH_SHORT).show();
                txt.setText(s);
            }
        }
    }
}
