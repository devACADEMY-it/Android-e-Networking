/*
 * Android e Networking
 * Gestione errori in Volley
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.volley;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

public class MainActivity extends AppCompatActivity {

    private TextView txt;
    private RequestQueue requestQueue;
    private final static String REMOTE_ADDR="http://loripsum.net/dsdfvsdvsdcsdc";

    Response.Listener<String> listener = new Response.Listener<String>(){

        @Override
        public void onResponse(String response) {
            txt.setText(response);
        }
    };

    private Response.ErrorListener errorListener = new Response.ErrorListener(){

        @Override
        public void onErrorResponse(VolleyError error) {
            int codiceErrore = error.networkResponse.statusCode;
            Toast.makeText(MainActivity.this, "Codice errore " + codiceErrore, Toast.LENGTH_LONG).show();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txt = (TextView) findViewById(R.id.txt);

        requestQueue = Volley.newRequestQueue(this);
    }

    public void avvia(View v){
        requestQueue.add(preparaRichiesta());
    }

    private StringRequest preparaRichiesta(){
        StringRequest sr = new StringRequest(REMOTE_ADDR, listener, errorListener);
        return sr;
    }
}
