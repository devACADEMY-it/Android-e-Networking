/*
 * Android e Networking
 * Soluzione Seconda Esercitazione: "RSS e WebView"
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.rss;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.io.IOException;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ListView listView;
    private ArrayAdapter<Notizia> adapter;

    private RequestQueue mRequestQueue = null;

    private final static String NEWS_URL="http://www.ansa.it/sito/notizie/cultura/cinema/cinema_rss.xml";

    private Response.Listener<String> listener = new Response.Listener<String>(){
        @Override
        public void onResponse(String s) {
            try {
                List<Notizia> notizie = RssDomParser.parseXML(s);
                adapter.addAll(notizie);
            } catch (IOException e){}


        }
    };

    private Response.ErrorListener errorListener = new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError volleyError) {
            Toast.makeText(MainActivity.this, "Errore", Toast.LENGTH_LONG).show();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = (ListView) findViewById(R.id.listview);
        adapter = new ArrayAdapter(this, R.layout.row, R.id.rtitle);
        listView.setAdapter(adapter);

        mRequestQueue = Volley.newRequestQueue(this);

        mRequestQueue.add(preparaRichiesta());
    }

    private Request<String> preparaRichiesta(){
        return new StringRequest(NEWS_URL, listener, errorListener);
    }
}
