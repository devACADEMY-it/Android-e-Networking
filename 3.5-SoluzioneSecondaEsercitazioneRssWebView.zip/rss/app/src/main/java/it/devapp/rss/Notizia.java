/*
 * Android e Networking
 * Soluzione Seconda Esercitazione: "RSS e WebView"
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.rss;

public class Notizia {
    private String titolo;
    private String url;

    public String getTitolo() {
        return titolo;
    }

    public void setTitolo(String titolo) {
        this.titolo = titolo;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String toString(){return getTitolo();}

}
