/*
 * Android e Networking
 * Soluzione Seconda Esercitazione: "RSS e WebView"
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.rss;

import android.provider.DocumentsContract;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

public class RssDomParser {
    public static List<Notizia> parseXML(String rss) throws IOException{
        List<Notizia> res = new ArrayList();
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = null;
        try{
            builder = factory.newDocumentBuilder();
        } catch (ParserConfigurationException e){}

        try{
            Document doc = builder.parse(new InputSource(new StringReader(rss)));
            doc.normalize();
            NodeList list = doc.getElementsByTagName("item");
            for (int i = 0; i<list.getLength(); i++){
                Node n = list.item(i);
                if(n.getNodeType() == Node.ELEMENT_NODE){
                    Element e = (Element) n;
                    Notizia notizia = new Notizia();
                    notizia.setTitolo(e.getElementsByTagName("title").item(0).getTextContent().trim());
                    notizia.setUrl(e.getElementsByTagName("guid").item(0).getTextContent().trim());
                    res.add(notizia);
                }
            }
        } catch (SAXException e) {
            return null;
        }
        return res;
    }
}
