/*
 * Android e Networking
 * ImageRequest
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.omdb;

public class Film {
    String Title;
    String Plot;
    String Poster;
    String Year;
    String Actors;
}
