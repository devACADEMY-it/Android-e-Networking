/*
 * Android e Networking
 * Interrompere le attività asincrone
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.asynctask;

import android.os.AsyncTask;
import android.support.annotation.IntegerRes;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private TextView txt;
    private BackgroundTask task;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txt = (TextView) findViewById(R.id.txt);
    }

    public void avvia(View v){

        task = new BackgroundTask();
        task.execute();

    }

    public void interrompi(View v){

        if (task != null){
            task.cancel(true);
        }

    }

    private class BackgroundTask extends AsyncTask<Void, Integer, Void>{

        @Override
        protected Void doInBackground(Void... params) {

            for (int i=1; i<=100 && !isCancelled(); i++){
                try {
                    Thread.sleep(50);
                    publishProgress(i);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            return null;
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
            txt.setText(Integer.toString(values[0])+"%");
        }

        @Override
        protected void onCancelled() {
            Toast.makeText(MainActivity.this, "Interrotto!", Toast.LENGTH_LONG).show();
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            Toast.makeText(MainActivity.this, "Operazioni concluse!", Toast.LENGTH_LONG).show();
        }
    }
}
