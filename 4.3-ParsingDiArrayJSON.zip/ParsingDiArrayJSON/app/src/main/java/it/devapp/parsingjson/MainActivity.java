/*
 * Android e Networking
 * Parsing di array JSON
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.parsingjson;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    private ListView listView;
    private ArrayAdapter<String> adapter;

    private void parsing() {

        String json=getString(R.string.esempiojson);

        try {
            JSONArray ob=new JSONArray(json);

            for(int i=0; i<ob.length(); i++)
            {
                String s=ob.getJSONObject(i).getString("nome")+" "+ob.getJSONObject(i).getString("cognome")+
                        " di anni "+ob.getJSONObject(i).getInt("eta");
                adapter.add(s);
            }
        } catch (JSONException e) {

        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        adapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1);
        listView= (ListView) findViewById(R.id.lista);
        listView.setAdapter(adapter);
    }

    public void aggiorna(View v)
    {
        parsing();
    }


}
